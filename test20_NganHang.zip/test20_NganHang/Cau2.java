//bai demo
package test20_NganHang;

import java.util.Scanner;

public class Cau2 {

    public static void main(String[] args) {
        NganHang n = new NganHang();
        Scanner in = new Scanner(System.in);
        n.nhapGDVang(in);
        n.NhapGDTT(in);
        n.NhapGDTT(in);
        n.out();
    }
}
//input
//1/2/2022
//23
//10
//9999
//3/4/2023
//100
//20
//Vnd
//6/7/2023
//100
//10
//Usd
//23