
package test20_NganHang;

public interface IGiaoDich {
    public double getThanhTien();
}
